package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import stepDef.Hooks;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class P02_KSA_SubscriptionPage {
    /***************************************************************************/
    public void KSA_SubscriptionPage()
    {
        Hooks.driver.navigate().to("https://subscribe.stctv.com/sa-en");
    }
    /***************************************************************************/

    // Create an expected subscription type list of strings
    public List<String> expectedSubscriptionTypeList = Arrays.asList("LITE", "CLASSIC", "PREMIUM");

    // Create a new list of strings to hold the actual subscription type  of the elements
    public List<String> actualSubscriptionTypeList = new ArrayList<>();
    /***************************************************************************/
    // Create an expected subscription price list of strings
    public List<String> expectedSubscriptionPriceCurrencyListKSA = Arrays.asList("15 SAR/month", "25 SAR/month", "60 SAR/month");

    // Create a new list of strings to hold the actual subscription type  of the elements
    public List<String> actualSubscriptionPriceCurrencyListKSA = new ArrayList<>();
    /***************************************************************************/

    public void listOfSubscriptionType() {
        List<WebElement> elements = Hooks.driver.findElements(By.cssSelector("strong[class=\"plan-title\"]"));

        // Iterate through the list of WebElements and extract their text
        for (WebElement element : elements) {
            actualSubscriptionTypeList.add(element.getText());
        }
        System.out.println(actualSubscriptionTypeList);
    }
    /***************************************************************************/
    public void listOfSubscriptionPriceCurrencyKSA() {
        List<WebElement> elements = Hooks.driver.findElements(By.xpath("//div[contains(@id, 'currency')]"));

        // Iterate through the list of WebElements and extract their text
        for (WebElement element : elements) {
            actualSubscriptionPriceCurrencyListKSA.add(element.getText());

        }
        System.out.println(actualSubscriptionPriceCurrencyListKSA);
    }
    /***************************************************************************/
}

