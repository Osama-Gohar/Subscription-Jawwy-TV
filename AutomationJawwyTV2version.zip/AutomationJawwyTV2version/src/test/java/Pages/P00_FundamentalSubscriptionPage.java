package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import stepDef.Hooks;

public class P00_FundamentalSubscriptionPage<elements> {

    // subscription page web element
    public WebElement subscriptionPage() {

        return Hooks.driver.findElement(By.partialLinkText("Start Your Free Trial"));
    }
    /*************************************************************************/
    // country button web element
    public WebElement country() {

        return Hooks.driver.findElement(By.id("country-btn"));
        // By countryButton = By.cssSelector("a[id=\"country-btn\"]");
        // return Hooks.driver.findElement(countryButton);
    }
    /*************************************************************************/
    // Sign in button web element
    public WebElement signin() {

        return Hooks.driver.findElement(By.id("signin"));
        // return Hooks.driver.findElement(By.cssSelector("a[id=\"signin\"]"));
    }
    /*************************************************************************/
    /* translation button web element (AR,EN) */
    public WebElement translation() {

        return Hooks.driver.findElement(By.id("translation-btn"));
        // return Hooks.driver.findElement(By.cssSelector("a[id=\"translation-btn\"]"));
    }
    /*************************************************************************/
  /*  public List<WebElement> elements = Hooks.driver.findElements(By.cssSelector("strong[class=\"plan-title\"]"));
    // Create an expected list of strings
    List<String> expectedList = Arrays.asList("LITE", "CLASSIC", "PREMIUM");

    // Create a new list of strings to hold the actual values of the elements
    List<String> actualList = new ArrayList<>();

    // Iterate through the list of WebElements and extract their text
*/


}
