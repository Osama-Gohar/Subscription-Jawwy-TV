package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import stepDef.Hooks;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class P01_BahrainSubscriptionPage {


    /***************************************************************************/

    public void BahrainSubscriptionPage()
    {
         Hooks.driver.navigate().to("https://subscribe.stctv.com/bh-en");
    }
    /***************************************************************************/

    // Create an expected subscription type list of strings
    public List<String> expectedSubscriptionTypeList = Arrays.asList("LITE", "CLASSIC", "PREMIUM");

    // Create a new list of strings to hold the actual subscription type  of the elements
    public List<String> actualSubscriptionTypeList = new ArrayList<>();
    /***************************************************************************/
    // Create an expected subscription price list of strings
    public List<String> expectedSubscriptionPriceCurrencyListBahrain = Arrays.asList("2 BHD/month", "3 BHD/month", "6 BHD/month");

    // Create a new list of strings to hold the actual subscription type  of the elements
    public List<String> actualSubscriptionPriceCurrencyListBahrain = new ArrayList<>();
    /***************************************************************************/

    public void listOfSubscriptionType() {
        List<WebElement> elements = Hooks.driver.findElements(By.cssSelector("strong[class=\"plan-title\"]"));

        // Iterate through the list of WebElements and extract their text
        for (WebElement element : elements) {
            actualSubscriptionTypeList.add(element.getText());
        }
        System.out.println(actualSubscriptionTypeList);
    }
    /***************************************************************************/
    public void listOfSubscriptionPriceCurrencyBahrain() {
        List<WebElement> elements = Hooks.driver.findElements(By.xpath("//div[contains(@id, 'currency')]"));

        // Iterate through the list of WebElements and extract their text
        for (WebElement element : elements) {
            actualSubscriptionPriceCurrencyListBahrain.add(element.getText());

        }
        System.out.println(actualSubscriptionPriceCurrencyListBahrain);
    }
    /***************************************************************************/



}
