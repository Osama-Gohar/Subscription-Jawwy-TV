package stepDef;
import Pages.P02_KSA_SubscriptionPage;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.testng.Assert;
import utilities.BrowserUtils;

public class D02_KSA_SubscriptionStepDef {

    P02_KSA_SubscriptionPage KSA = new P02_KSA_SubscriptionPage();


    @Given ("I am on the Jawwy TV application home page")
    public void jawwyTvhomePage()
    {
        BrowserUtils.waitFor(3);

    }
    @When("I navigate to the subscription packages page")
    public void navigateToKSASubscriptionPage()
    {
        KSA.KSA_SubscriptionPage();
        BrowserUtils.waitFor(2);
        KSA.listOfSubscriptionType();
        KSA.listOfSubscriptionPriceCurrencyKSA();

    }
    @Then("I should see the three subscription packages [LITE, CLASSIC, PREMIUM]")
    public void verifyKSAPackage()
    {
        Assert.assertEquals(KSA.actualSubscriptionTypeList,KSA.expectedSubscriptionTypeList);

    }

    @Then("I should see the price_currency per month for all subscription packages should be")
    public void verifyKSAPriceCurrency()
    {
        Assert.assertEquals(KSA.actualSubscriptionPriceCurrencyListKSA,KSA.expectedSubscriptionPriceCurrencyListKSA);
    }

}
