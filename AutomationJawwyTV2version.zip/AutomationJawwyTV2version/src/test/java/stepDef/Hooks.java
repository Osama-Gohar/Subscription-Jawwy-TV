package stepDef;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import java.util.concurrent.TimeUnit;

public class Hooks {

   public static WebDriver driver;

    @Before
    public void Open_Driver()
    {
        //1- bridge between test scripts and browser
        ChromeOptions Options = new ChromeOptions();
        String ChromePath = System.getProperty("user.dir") + "\\src\\main\\resources\\chromedriver.exe";
        System.setProperty("webdriver.chrome.driver" , ChromePath);

        Options.addArguments("--remote-allow-origins=*");

        //2- new object of web driver
        driver = new ChromeDriver(Options);

        //3- navigate to website
        driver.navigate().to("https://subscribe.stctv.com/bh-en");
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(7, TimeUnit.SECONDS);

    }
    @After
    public void Close_Driver()
    {
        driver.quit();
    }
}
