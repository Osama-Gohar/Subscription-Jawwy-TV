package stepDef;


import Pages.P01_BahrainSubscriptionPage;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.testng.Assert;
import utilities.BrowserUtils;

public class D01_BahrainSubscriptionStepDef {

    P01_BahrainSubscriptionPage BahrainSP = new P01_BahrainSubscriptionPage();


    @Given ("I am on the Jawwy TV application home page")
    public void jawwyTvhomePage()
    {
        BrowserUtils.waitFor(3);
       // throw new io.cucumber.java.PendingException();
    }
    @When("I navigate to the subscription packages page")
    public void navigateToBahrainSubscriptionPage()
    {
        BahrainSP.BahrainSubscriptionPage();
        BrowserUtils.waitFor(2);
        BahrainSP.listOfSubscriptionType();
        BahrainSP.listOfSubscriptionPriceCurrencyBahrain();

    }
    @Then("I should see the three subscription packages [LITE, CLASSIC, PREMIUM]")
    public void verifyBahrainPackage()
    {
        Assert.assertEquals(BahrainSP.actualSubscriptionTypeList,BahrainSP.expectedSubscriptionTypeList);

    }

    @Then("I should see the price_currency per month for all subscription packages should be")
    public void verifyBahrainPriceCurrency()
    {
        Assert.assertEquals(BahrainSP.actualSubscriptionPriceCurrencyListBahrain,BahrainSP.expectedSubscriptionPriceCurrencyListBahrain);
    }

}
