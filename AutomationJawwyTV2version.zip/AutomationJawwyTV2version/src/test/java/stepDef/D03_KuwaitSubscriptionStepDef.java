package stepDef;

import Pages.P03_KuwaitSubscriptionPage;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.testng.Assert;
import utilities.BrowserUtils;

public class D03_KuwaitSubscriptionStepDef {

    P03_KuwaitSubscriptionPage Kuwait = new P03_KuwaitSubscriptionPage();


    @Given ("I am on the Jawwy TV application home page")
    public void jawwyTvhomePage()
    {
        BrowserUtils.waitFor(3);

    }
    @When("I navigate to the subscription packages page")
    public void navigateToKuwaitSubscriptionPage()
    {
        Kuwait.KuwaitSubscriptionPage();
        BrowserUtils.waitFor(2);
        Kuwait.listOfSubscriptionType();
        Kuwait.listOfSubscriptionPriceCurrencyKuwait();

    }
    @Then("I should see the three subscription packages [LITE, CLASSIC, PREMIUM]")
    public void verifyKuwaitPackage()
    {
        Assert.assertEquals(Kuwait.actualSubscriptionTypeList,Kuwait.expectedSubscriptionTypeList);

    }

    @Then("I should see the price_currency per month for all subscription packages should be")
    public void verifyKuwaitPriceCurrency()
    {
        Assert.assertEquals(Kuwait.actualSubscriptionPriceCurrencyListKuwait,Kuwait.expectedSubscriptionPriceCurrencyListKuwait);
    }


}
