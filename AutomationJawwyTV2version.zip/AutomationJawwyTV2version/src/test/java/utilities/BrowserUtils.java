package utilities;

public class BrowserUtils {

    public static void waitFor(int second)
    {
        try {
            Thread.sleep(second * 1000L);
        } catch (InterruptedException e){
            e.printStackTrace();
            //Thread.currentThread().interrupt();
        }
    }

}
